# Sri Madhuram: backend / Supabase review

Reviewed: api.js, server.js, supabaseclient.js, db.js, index_1.html, api_test.js, package.json, SUPABASE_SETUP.md, _env, _gitignore_1.
NOT provided (so not checked): supabase/migrations/*.sql, COMPLETE_SETUP.sql, scripts/import-legacy-data.js.
Not run: `npm test` (no node_modules / no network here). Fixes were syntax-checked and the pure logic was exercised with stand-ins.

## URGENT (do first)
1. The `_env` file you shared contains live secrets (Supabase service-role key, secret key, database password, DATABASE_URL, ADMIN_API_KEY). Treat them as exposed: rotate the service-role/secret keys and the DB password in Supabase, replace ADMIN_API_KEY, update your host's settings. Never upload .env again.
2. Remove unused/duplicate values from .env (ADMIN_API_KEY, SUPABASE_SECRET_KEY, lowercase host/port/database/user/password) once nothing uses them.

## Fixed in the files in this folder
| # | Problem | Fix |
|---|---------|-----|
| 1 | No rate limit on send-otp, verify-otp, customer/admin login, register (OTP email spam, password guessing) | In-memory limiter on those routes. Behind a proxy set `TRUST_PROXY=1` or all visitors share one limit |
| 2 | Deleted dishes could reappear: public API read unavailable dishes with the public key, which RLS hides, so the "hidden dishes" list was always empty | Read it with the server key (falls back to empty if not configured) |
| 3 | Admin could not re-add a dish after deleting it (409 "already exists") | Re-adding a removed dish restores it with the new price/image |
| 4 | Order status could be set backwards (Delivered to Pending) or skipped; bad order ID gave a 500 | Forward-only, atomic update; ID validated as UUID |
| 5 | Poster validation only checked title/image; description, dates, button URL, is_published went to the database unchecked | Full validation (http/https URLs only) |
| 6 | Saving many dishes/posters could exceed the 20 kb JSON limit | 512 kb limit on admin menu/poster routes only |
| 7 | Saving draft dishes inserted one by one, so a failure left a half-saved menu | One batched insert: all or nothing |
| 8 | Poster expiry used the UTC date | Uses India date |
| 9 | Unknown /api routes returned an HTML 404; bad JSON leaked a parser message | Clean JSON errors |
| 10 | Dish names inserted unescaped into the table/kitchen/receipt screens (stored XSS from a bad menu name) | escapeHtml added (index.html) |
| 11 | server.js imported express but never used it | Removed |

## Not fixed: needs your decision or the SQL files
- **Staff login is not real.** In index.html, choosing "Staff" at sign-in needs no password, and the backend has no staff role (only customer/admin). Table orders, kitchen screen and receipts exist only in the browser's memory, so they are lost on refresh and are not stored in Supabase. The requirements ask for staff accounts and saved dine-in orders: this needs a backend design (staff role + dine-in order tables/routes).
- **Demo data in the Staff screen:** tables 2 and 6 start "occupied" with sample items.
- **Paid but no order:** if UPI payment succeeds but order creation fails, the customer is charged with no order. Retry works (same payment ID is returned), but nothing refunds or alerts you automatically. Check the Razorpay dashboard regularly; consider a payment-reconciliation job.
- **Possible double order:** two simultaneous requests with the same Razorpay payment ID can both pass the "already exists" check. Add a UNIQUE index on `orders(razorpay_payment_id)` (where not null) if the migration doesn't have one.
- **Rounding:** `getOrderAmount` rounds the total to whole rupees. Make sure `create_customer_order` uses the same total, otherwise `total` and `paid_amount` differ and refund maths is off.
- **Refund webhook race:** a refund event that arrives before the refund ID is saved on the order is ignored.
- **Unused files/packages:** db.js (ESM `import` in a CommonJS project, would crash if loaded), `postgres`, `prisma` (release candidate), `@supabase/server`. Remove with `npm uninstall postgres prisma @supabase/server` and delete db.js. (I did not edit package.json: it would put package-lock.json out of sync.)
- **Address lookup** sends the customer's GPS position to OpenStreetMap's public service. Mention it in your privacy text; heavy use needs your own geocoder.
- **Refund policy** (10% deduction at delivery stage) still needs the owner's written approval, as your own setup notes say.
- **Tests:** api_test.js reads the web page from disk and calls `/api` routes; run `npm test` locally after replacing the files. Add tests for the new rules (rate limit, forward-only order status).

## How to apply
Copy api.js, server.js and index.html from this folder over your project (index.html replaces your `index.html`). Then `npm start` and `npm test`.
